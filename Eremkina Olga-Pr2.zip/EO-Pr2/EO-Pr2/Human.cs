﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr2
{
    abstract class Human
    {
        private string N = "NoName";

        public string Name
        {
            get { return N; }
            set { this.N = value; }
        }

        public abstract void Origin();
        public abstract void SayHi();        
    }
}
