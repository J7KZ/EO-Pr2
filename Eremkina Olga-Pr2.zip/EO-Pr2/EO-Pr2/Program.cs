﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr2
{
    class Program
    {
        static void Main(string[] args)
        {
            RusH R = new RusH();
            EngH E = new EngH();
            FranH F = new FranH();
            R.Name = "Иван";
            F.Name = "Oliver";
            int or;
            Random Arnd = new Random();
            or = Arnd.Next(1, 5);
            switch (or)
                { 
                case 1:
                    R.SayHi();
                    Console.WriteLine("Меня зовут {0}",R.Name);
                    R.Origin();
                    break;
                case 2:
                    E.SayHi();
                    Console.WriteLine("My name is {0}",E.Name);
                    E.Origin();
                    break;
                case 3:
                    F.SayHi();
                    Console.WriteLine("Je m'appelle {0}",F.Name);
                    F.Origin();
                    break;
                default:
                    Console.WriteLine("Ошибка");                    
                    break;
            }

            Console.ReadKey();
        }          
    } 
}

