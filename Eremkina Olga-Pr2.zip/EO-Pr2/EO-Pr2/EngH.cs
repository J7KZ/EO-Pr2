﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr2
{
    class EngH : Human
    {
        public override void Origin()
        {
            Console.WriteLine("My country is Great Britan");
        }

        public override void SayHi()
        {
            Console.WriteLine("Hello!");
        }
    }
}
