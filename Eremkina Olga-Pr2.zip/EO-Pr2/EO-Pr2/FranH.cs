﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr2
{
    class FranH : Human
    {
        public override void Origin()
        {
           Console.WriteLine("Mon pays la France");
        }

        public override void SayHi()
        {
            Console.WriteLine("Salut!");
        }
    }
}
